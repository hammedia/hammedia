#!/bin/zsh

set -u

scan_root="${1:-${HOME}/Documents}"
script_dir="${0:A:h}"
bundle_root="${script_dir:h}"

if [[ ! -d "$scan_root" ]]; then
  print -r -- "탐색 기준 폴더를 찾지 못했습니다: $scan_root"
  exit 2
fi

folder_names=(
  "김비서 업무"
  "1.MCi"
  "2.Shrimp"
  "TFT"
  "앱 홍보"
  "WWR"
)

display_names=(
  "김비서(일반 질문)"
  "1.MCi"
  "2.Shrimp"
  "TFT"
  "앱 홍보"
  "WWR"
)

print -r -- $'상자 이름\t상태\t기존 폴더'

for index in {1..6}; do
  folder_name="${folder_names[$index]}"
  display_name="${display_names[$index]}"
  matches=()
  while IFS= read -r match; do
    [[ -n "$match" ]] && matches+=("$match")
  done < <(
    find "$scan_root" \
      -maxdepth 4 \
      -type d \
      -name "$folder_name" \
      ! -path "${bundle_root}/boxes/*" \
      -print 2>/dev/null
  )
  match_count=${#matches[@]}

  if (( match_count == 0 )); then
    print -r -- "${display_name}"$'\t'"미발견"$'\t'
    continue
  fi

  if (( match_count > 1 )); then
    joined_matches="${(j: | :)matches}"
    print -r -- "${display_name}"$'\t'"충돌"$'\t'"${joined_matches}"
    continue
  fi

  target_folder="${matches[1]}"
  if [[ -e "${target_folder}/AGENTS.md" ]]; then
    print -r -- "${display_name}"$'\t'"충돌"$'\t'"${target_folder}"
  else
    print -r -- "${display_name}"$'\t'"발견"$'\t'"${target_folder}"
  fi
done
