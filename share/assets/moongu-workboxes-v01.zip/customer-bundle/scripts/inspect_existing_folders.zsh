#!/bin/zsh

set -u

script_dir="${0:A:h}"
bundle_root="${script_dir:h:A}"

if (( $# != 1 )); then
  print -r -- "확인할 프로젝트 폴더 경로 하나를 알려주세요."
  exit 2
fi

input_path="$1"

if [[ -z "${input_path//[[:space:]]/}" ]]; then
  print -r -- "확인할 프로젝트 폴더 경로 하나를 알려주세요."
  exit 2
fi

if [[ "$input_path" == "~" ]]; then
  target_path="$HOME"
elif [[ "$input_path" == "~/"* ]]; then
  target_path="${HOME}/${input_path#\~/}"
else
  target_path="$input_path"
fi

target_path="${target_path:A}"

print -r -- $'프로젝트 폴더 경로\t확인 결과'

if [[ "$target_path" == "$bundle_root" || "$target_path" == "$bundle_root/"* ]]; then
  print -r -- "${target_path}"$'\t'"팩 내부 경로"
  exit 0
fi

if [[ ! -d "$target_path" ]]; then
  print -r -- "${target_path}"$'\t'"경로 없음"
elif [[ -e "${target_path}/AGENTS.md" ]]; then
  print -r -- "${target_path}"$'\t'"충돌"
else
  print -r -- "${target_path}"$'\t'"사용 가능"
fi
